# Tharanidharan B A | Personal Portfolio

A responsive, dark professional portfolio website.

- **Course:** B.Sc. Artificial Intelligence & Machine Learning
- **College:** KPR College of Arts Science and Research
- **Interests:** AI, machine learning, data analytics and web development

## Featured projects
- **LegalEase:** AI-powered legal document generator (Naan Mudhalvan / TN Skills team project; SQLite database work).
- **IntelliCampus AI:** Student performance and placement analytics system.
- **Complaint Management System:** PHP and MySQL web application.
- **News Portal:** Internship web project.
- **Walmart Sales Data Analysis:** SQL and Python data cleaning and EDA exercises.

## Technologies
Python, Flask, PHP, MySQL, SQLite, HTML, CSS, JavaScript, Pandas, Matplotlib, Power BI, Excel.

## Publish with GitHub Pages
1. Upload `index.html`, `README.md`, and `.nojekyll` to the root of this repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**, then click **Save**.
5. The site should be published at: https://tharani2604.github.io/portfolio/

## Contact
GitHub: https://github.com/tharani2604

Add verified LinkedIn, email, resume and certificate links when ready.
